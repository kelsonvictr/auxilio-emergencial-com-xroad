//
//  SciterAppDelegate.h
//  layered
//
//  Created by andrew on 2014-04-17.
//  Copyright (c) 2014 andrew fedoniouk. All rights reserved.
//

#import <Cocoa/Cocoa.h>

@interface SciterAppDelegate : NSObject <NSApplicationDelegate>

@property (assign) IBOutlet NSWindow *window;

@end
