# chmod +x for binaries
ls -I *.so -I *.sh . | xargs chmod +x
