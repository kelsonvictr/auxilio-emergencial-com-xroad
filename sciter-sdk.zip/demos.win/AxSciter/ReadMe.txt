COM/ActiveX Sciter Wrapper

Very minimal implementation so far. Only sciter.LoadHtml() and sciter.LoadHtmlFile() methods.