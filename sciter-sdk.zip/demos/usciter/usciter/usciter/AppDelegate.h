//
//  AppDelegate.h
//  usciter
//
//  Created by Andrew Fedoniouk on 2018-07-03.
//  Copyright © 2018 Andrew Fedoniouk. All rights reserved.
//

#import <Cocoa/Cocoa.h>

@interface AppDelegate : NSObject <NSApplicationDelegate>


@end

