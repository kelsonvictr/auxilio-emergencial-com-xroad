//
//  AppDelegate.m
//  ulayered
//
//  Created by Andrew Fedoniouk on 2014-12-28.
//  Copyright (c) 2014 Andrew Fedoniouk. All rights reserved.
//

#import "AppDelegate.h"

@interface AppDelegate ()
@end

@implementation AppDelegate

- (void)applicationDidFinishLaunching:(NSNotification *)aNotification {
    // Insert code here to initialize your application
}

- (void)applicationWillTerminate:(NSNotification *)aNotification {
    // Insert code here to tear down your application
}

@end
