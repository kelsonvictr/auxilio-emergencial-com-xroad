//
//  AppDelegate.h
//  notes
//
//  Created by Andrew Fedoniouk on 2017-08-01.
//  Copyright © 2017 Andrew Fedoniouk. All rights reserved.
//

#import <Cocoa/Cocoa.h>

@interface AppDelegate : NSObject <NSApplicationDelegate>


@end

